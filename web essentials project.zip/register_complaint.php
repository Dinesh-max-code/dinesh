<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register Complaint</title>
    <style>
        /* CSS styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }
        h1 {
            text-align: center;
            margin-top: 20px;
            color: #333;
        }
        .container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 20px;
            box-sizing: border-box;
        }
        .form-container {
            margin-bottom: 20px;
        }
        form {
            padding: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        form label {
            font-weight: bold;
            color: #555;
        }
        form input[type="text"],
        form textarea,
        form select {
            width: calc(100% - 22px);
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        form button[type="submit"],
        form button[type="button"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
            transition: background-color 0.3s;
        }
        form button[type="submit"]:hover,
        form button[type="button"]:hover {
            background-color: #45a049;
        }
        #output {
            display: none;
            background-color: #e7f5e9;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
            transition: all 0.3s ease;
        }
        #output.success {
            border-left: 6px solid #4CAF50;
        }
        #output.error {
            border-left: 6px solid #f44336;
            background-color: #f8d7da;
        }
        #output p {
            margin: 5px 0;
        }
        .output-icon {
            font-size: 24px;
            margin-right: 10px;
        }
        .output-icon.success {
            color: #4CAF50;
        }
        .output-icon.error {
            color: #f44336;
        }
    </style>
</head>
<body>
    <h1>Register Complaint</h1>
    <div class="container">
        <div class="form-container">
            <form id="complaintForm" action="" method="post">
                <label for="customerName">Customer Name:</label>
                <input type="text" id="customerName" name="customerName" required>
                <label for="contactNumber">Contact Phone #:</label>
                <input type="text" id="contactNumber" name="contactNumber" required pattern="\d{10}">
                <label for="product">Product:</label>
                <select id="product" name="product">
                    <option value="P001">Product A</option>
                    <option value="P002">Product B</option>
                    <option value="P003">Product C</option>
                </select>
                <label for="complaintType">Complaint Type:</label>
                <select id="complaintType" name="complaintType">
                    <option value="1">Equipment malfunction</option>
                    <option value="2">Price charged is too high</option>
                    <option value="3">Service not rendered in time</option>
                    <option value="4">Service center not responsive</option>
                    <option value="5">Others</option>
                </select>
                <label for="complaintDetails">Complaint Description:</label>
                <textarea id="complaintDetails" name="complaintDetails"></textarea>
                <center> <button type="submit">Submit</button>
                <button type="button" onclick="clearForm()">Clear</button>
                <button type="button" onclick="navigateTo('index')">Back</button></center>
            </form>
        </div>
        <div id="output"></div>
    </div>

    <script>
        // JavaScript enhanced validation function
        document.getElementById('complaintForm').addEventListener('submit', function(event) {
            // Clear previous messages
            clearOutput();

            // Get form elements
            let customerName = document.getElementById('customerName');
            let contactNumber = document.getElementById('contactNumber');
            let complaintDetails = document.getElementById('complaintDetails');
            let product = document.getElementById('product');
            let complaintType = document.getElementById('complaintType');

            // Validation flags
            let isValid = true;
            let messages = [];

            // Validate customer name
            if (customerName.value.trim() === "") {
                isValid = false;
                messages.push("Customer Name is required.");
                customerName.style.borderColor = 'red';
            } else if (customerName.value.trim().length < 3 || customerName.value.trim().length > 50) {
                isValid = false;
                messages.push("Customer Name must be between 3 and 50 characters.");
                customerName.style.borderColor = 'red';
            } else if (!/^[a-zA-Z\s]+$/.test(customerName.value.trim())) {
                isValid = false;
                messages.push("Customer Name should contain only letters and spaces.");
                customerName.style.borderColor = 'red';
            } else {
                customerName.style.borderColor = '';
            }

            // Validate contact number
            if (contactNumber.value.trim() === "") {
                isValid = false;
                messages.push("Contact Phone Number is required.");
                contactNumber.style.borderColor = 'red';
            } else if (!/^\d{10}$/.test(contactNumber.value.trim())) {
                isValid = false;
                messages.push("Contact Phone Number should be exactly 10 digits.");
                contactNumber.style.borderColor = 'red';
            } else {
                contactNumber.style.borderColor = '';
            }

            // Validate product selection
            if (product.value.trim() === "") {
                isValid = false;
                messages.push("Product must be selected.");
                product.style.borderColor = 'red';
            } else {
                product.style.borderColor = '';
            }

            // Validate complaint type selection
            if (complaintType.value.trim() === "") {
                isValid = false;
                messages.push("Complaint Type must be selected.");
                complaintType.style.borderColor = 'red';
            } else {
                complaintType.style.borderColor = '';
            }

            // Validate complaint details
            if (complaintDetails.value.trim() === "") {
                isValid = false;
                messages.push("Complaint Description is required.");
                complaintDetails.style.borderColor = 'red';
            } else if (complaintDetails.value.trim().length < 10 || complaintDetails.value.trim().length > 500) {
                isValid = false;
                messages.push("Complaint Description must be between 10 and 500 characters.");
                complaintDetails.style.borderColor = 'red';
            } else if (!/^[a-zA-Z0-9\s,.\-!@#$%^&*()]+$/.test(complaintDetails.value.trim())) {
                isValid = false;
                messages.push("Complaint Description contains invalid characters.");
                complaintDetails.style.borderColor = 'red';
            } else {
                complaintDetails.style.borderColor = '';
            }

            // If form is invalid, prevent submission and show errors
            if (!isValid) {
                event.preventDefault();
                displayErrorMessages(messages);
            }
        });

        // Clear output function
        function clearOutput() {
            document.getElementById('output').innerHTML = '';
            document.getElementById('output').style.display = 'none';
        }

        // Function to display error messages
        function displayErrorMessages(messages) {
            let output = document.getElementById('output');
            output.className = 'error'; // Add error class
            output.style.display = 'block';
            messages.forEach(function(message) {
                let p = document.createElement('p');
                p.innerHTML = '<span class="output-icon error">&#10007;</span> ' + message;
                output.appendChild(p);
            });
        }

        // Clear form function
        function clearForm() {
            document.getElementById('complaintForm').reset();
            clearOutput();
        }

        // Navigate to another page function
        function navigateTo(page) {
            window.location.href = page + '.html';
        }
    </script>

    <?php
     include 'db.php';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
       // Get form data
$customerName = $_POST['customerName'];
$contactNumber = $_POST['contactNumber'];
$product = $_POST['product'];
$complaintType = $_POST['complaintType'];
$complaintDetails = $_POST['complaintDetails'];
$complaintDate = date('Y-m-d');
$status = 'Registered';
$statusDate = date('Y-m-d');

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO Complaint (Customer_Name, Contact_Number, Product_code, Complaint_details, Complaint_type, Complaint_date, Complaint_status, Status_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssss", $customerName, $contactNumber, $product, $complaintDetails, $complaintType, $complaintDate, $status, $statusDate);

// Execute the statement
if ($stmt->execute()) {
    $complaintNumber = $stmt->insert_id;
    $resolutionDate = date('Y-m-d', strtotime('+2 weeks'));

    // Display confirmation message in JavaScript
    echo "<script>
        let output = document.getElementById('output');
        output.className = 'success';
        output.style.display = 'block';
        output.innerHTML = '<p><span class=\"output-icon success\">&#10003;</span> Complaint Registered Successfully!</p>' +
                           '<p>Complaint Number: <strong>$complaintNumber</strong></p>' +
                           '<p>Expected Resolution Date: <strong>$resolutionDate</strong></p>';
        document.getElementById('complaintForm').reset(); // Clear the form
    </script>";
} else {
    // Display error message in JavaScript
    echo "<script>
        let output = document.getElementById('output');
        output.className = 'error';
        output.style.display = 'block';
        output.innerHTML = '<p><span class=\"output-icon error\">&#10007;</span> Error registering complaint: " . $conn->error . "</p>';
    </script>";
}

// Close the statement and connection
$stmt->close();
$conn->close();
}
?>

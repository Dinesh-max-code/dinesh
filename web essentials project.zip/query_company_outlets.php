<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Query Company Outlets</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .container {
            max-width: 600px;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            margin-top: 20px;
        }
        
        h1 {
            color: #4CAF50;
            text-align: center;
            margin-bottom: 20px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        
        th, td {
            padding: 15px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        
        th {
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }
        
        input[type="text"], input[type="radio"] {
            margin-right: 10px;
        }
        
        .button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 15px 30px;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 6px;
            transition: background-color 0.3s;
            display: block;
            margin: 0 auto;
            width: 50%;
            margin-top: 20px;
        }
        
        .button:hover {
            background-color: #45a049;
        }
        
        .back-button {
            display: inline-block;
            padding: 15px 30px;
            background-color: #333;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            transition: background-color 0.3s;
            display: block;
            margin: 0 auto;
            width: 50%;
            text-align: center;
        }
        
        .back-button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Query Company Outlets</h1>
        <!-- Form to select city and outlet type -->
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <table>
                <tr>
                    <th><label for="city">City:</label></th>
                    <td>
                        <select id="city" name="city" required>
                            <option value="">Select City</option>
                            <?php
                            include 'db.php';
                            // Fetch distinct cities from the Outlet table
                            $sql_cities = "SELECT DISTINCT City FROM Outlet";
                            $result_cities = $conn->query($sql_cities);

                            if ($result_cities->num_rows > 0) {
                                while($row = $result_cities->fetch_assoc()) {
                                    echo '<option value="' . $row["City"] . '">' . $row["City"] . '</option>';
                                }
                            } else {
                                echo '<option value="">No cities available</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="outlet_type">Outlet Type:</label></th>
                    <td>
                        <input type="radio" id="sales" name="outlet_type" value="Sales" required>
                        <label for="sales">Sales</label>
                        <input type="radio" id="service" name="outlet_type" value="Service" required>
                        <label for="service">Service</label>
                    </td>
                </tr>
            </table>
            <button type="submit" class="button">Submit</button><br>
        </form>

        <?php
        // Check if the form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Retrieve selected city and outlet type from the form
            $city = $_POST["city"];
            $outlet_type = $_POST["outlet_type"];

            // Map outlet type to corresponding numeric value (assuming outlet_type is an integer in the database)
            $outlet_type_map = [
                'Sales' => 1,
                'Service' => 2
            ];
            $outlet_type_value = $outlet_type_map[$outlet_type];

            // Prepare and execute SQL query based on the selected city and outlet type
            $sql = "SELECT * FROM Outlet WHERE City = ? AND Outlet_type = ?";
            $stmt = $conn->prepare($sql);

            if ($stmt === false) {
                die("Error preparing SQL statement: " . $conn->error);
            }

            // Bind parameters for the query
            $stmt->bind_param("si", $city, $outlet_type_value);

            // Execute the query
            if (!$stmt->execute()) {
                die("Error executing SQL statement: " . $stmt->error);
            }

            // Get result
            $result = $stmt->get_result();

            // Check if any rows are returned
            if ($result->num_rows > 0) {
                // Output outlet details
                echo "<h2>Outlet Details</h2>";
                echo "<table>";
                echo "<tr><th>OUTLET NUMBER</th><th>ADDRESS1</th><th>ADDRESS2</th><th>CITY</th><th>CONTACT NUMBER</th></tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["Outlet_number"] . "</td>";
                    echo "<td>" . $row["Address1"] . "</td>";
                    echo "<td>" . $row["Address2"] . "</td>";
                    echo "<td>" . $row["City"] . "</td>";
                    echo "<td>" . $row["Contact_Number"] . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "No outlets found for the selected city and outlet type.";
            }

            // Close the statement and connection
            $stmt->close();
            $conn->close();
        }
        ?>
        
        <a href="index.html" class="back-button">Back</a>
    </div>
</body>
</html>

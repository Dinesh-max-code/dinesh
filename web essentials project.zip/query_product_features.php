<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Query Product Features</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f5;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }
        header {
            background-color: #4CAF50;
            color: white;
            padding: 1em;
            width: 100%;
            text-align: center;
        }
        main {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
            padding: 20px;
            flex: 1;
        }
        form {
            max-width: 400px;
            width: 100%;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        label {
            margin-bottom: 10px;
            font-weight: bold;
        }
        select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            margin-bottom: 20px;
        }
        button, a {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s;
            margin-right: 10px;
        }
        button[type="button"] {
            background-color: #f44336;
        }
        button:hover, a:hover {
            background-color: #45a049;
        }
        .container {
            text-align: center;
        }
        h1 {
            color: white;
        }
	h2{
	   color:green;
	}
        .product-table {
            margin-top: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
            max-width: 800px;
            width: 100%;
            padding: 20px;
            box-sizing: border-box;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:hover {
            background-color: #f2f2f2;
        }
        .error-message {
            color: #f44336;
            font-weight: bold;
        }
        .back-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #333;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
            margin-top: 20px;
        }
        .back-button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <header>
        <h1>QUERY PRODUCT FEATURES</h1>
    </header>
    <main>
        <?php
        include 'db.php';

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Handle form submission
            $selected_product = $_POST["product"];
            $sql_product = "SELECT * FROM Product WHERE Product_Name = ?";
            $stmt_product = $conn->prepare($sql_product);

            if ($stmt_product === false) {
                die("Error preparing SQL statement: " . $conn->error);
            }

            $stmt_product->bind_param("s", $selected_product);

            if (!$stmt_product->execute()) {
                die("Error executing product SQL statement: " . $stmt_product->error);
            }

            $product_result = $stmt_product->get_result();

            if ($product_result->num_rows > 0) {
                echo '<div class="container">';
                echo '<h2>Product Features</h2>';
                echo '<div class="product-table">';
                echo "<table>";
                while ($product_row = $product_result->fetch_assoc()) {
                    echo "<tr><th>Product Code</th><td>" . $product_row["Product_code"] . "</td></tr>";
                    echo "<tr><th>Product Name</th><td>" . $product_row["Product_Name"] . "</td></tr>";
                    echo "<tr><th>Base Price</th><td>$" . $product_row["Base_Price"] . "</td></tr>";
                    echo "<tr><th>Warranty</th><td>" . $product_row["Warranty_months"] . " months</td></tr>";
                    echo "<tr><th>Launch Date</th><td>" . $product_row["Launch_date"] . "</td></tr>";
                }
                echo "</table>";
                echo '</div>';
                echo '</div>';
            } else {
                echo "<p class='error-message'>No product found with the selected code.</p>";
            }

            $stmt_product->close();
            $conn->close();
            echo '<a href="index.html" class="back-button">Back to Home</a>';
        } else {
            // Display form
            echo '<form action="" method="post">';
            echo '<div>';
            echo '<label for="product">Select Product</label>';
            echo '<select id="product" name="product">';
            
            $sql = "SELECT Product_Name FROM Product";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo '<option value="' . $row["Product_Name"] . '">' . $row["Product_Name"] . '</option>';
                }
            } else {
                echo '<option value="">No products available</option>';
            }

            echo '</select>';
            echo '</div>';
            echo '<div>';
            echo '<button type="submit">Show Product Details</button>';
            echo '<button type="button" onclick="clearFields()">Clear</button>';
            echo '<a href="index.html">Back</a>';
            echo '</div>';
            echo '</form>';
        }
        ?>
    </main>
    <script>
        function clearFields() {
            document.getElementById("product").selectedIndex = 0;
        }
    </script>
</body>
</html>

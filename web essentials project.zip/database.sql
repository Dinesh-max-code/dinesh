
-- Create database
CREATE DATABASE IF NOT EXISTS crm;
USE crm;

-- Create Product table
CREATE TABLE Product (
    Product_code CHAR(10) PRIMARY KEY,
    Product_Name CHAR(30),
    Base_Price INT(6),
    Warranty_months INT(2),
    Launch_date DATE,
    Battery_Price INT(6),
    Svc_at_Client_Place INT(2),
    Addl_warranty_peryear INT(2)
);

-- Insert sample data into Product table
INSERT INTO Product (Product_code, Product_Name, Base_Price, Warranty_months, Launch_date, Battery_Price, Svc_at_Client_Place, Addl_warranty_peryear) VALUES
('P001', 'Product A', 5000, 12, '2022-01-01', 1000, 5, 2),
('P002', 'Product B', 7000, 18, '2022-02-01', 1500, 6, 3),
('P003', 'Product C', 9000, 24, '2022-03-01', 2000, 7, 4);

-- Create Product_Feature table
CREATE TABLE Product_Feature (
    Product_Code CHAR(10),
    Feature_No INT(20),
    Feature_Desc CHAR(20),
    PRIMARY KEY (Product_Code, Feature_No),
    FOREIGN KEY (Product_Code) REFERENCES Product(Product_code)
);

-- Insert sample data into Product_Feature table
INSERT INTO Product_Feature (Product_Code, Feature_No, Feature_Desc) VALUES
('P001', 1, 'Feature 1'),
('P001', 2, 'Feature 2'),
('P002', 1, 'Feature 1'),
('P002', 2, 'Feature 2'),
('P003', 1, 'Feature 1'),
('P003', 2, 'Feature 2');

-- Create Outlet table
CREATE TABLE Outlet (
    Outlet_number INT AUTO_INCREMENT PRIMARY KEY,
    Outlet_type INT(2),
    Address1 CHAR(50),
    Address2 CHAR(50),
    City CHAR(20),
    Pincode INT(6),
    Contact_Number INT(10)
);

-- Insert sample data into Outlet table
INSERT INTO Outlet (Outlet_type, Address1, Address2, City, Pincode, Contact_Number) VALUES
(1, '123 Main St', 'Suite 1', 'City A', 123456, 1234567890),
(2, '456 Side St', 'Suite 2', 'City A', 123456, 1234567891),
(1, '789 High St', 'Suite 3', 'City B', 123457, 1234567892),
(2, '101 Low St', 'Suite 4', 'City B', 123457, 1234567893);

-- Create Complaint table
CREATE TABLE Complaint (
    Complaint_Number INT AUTO_INCREMENT PRIMARY KEY,
    Customer_Name CHAR(40),
    Contact_Number INT(10),
    Product_code CHAR(10),
    Complaint_details VARCHAR(200),
    Complaint_type INT(2),
    Complaint_date DATE,
    Complaint_status CHAR(20),
    Status_date DATE,
    FOREIGN KEY (Product_code) REFERENCES Product(Product_code)
);

-- Insert sample data into Complaint table
INSERT INTO Complaint (Customer_Name, Contact_Number, Product_code, Complaint_details, Complaint_type, Complaint_date, Complaint_status, Status_date) VALUES
('John Doe', 1234567890, 'P001', 'Equipment malfunction', 1, '2023-06-01', 'Registered', '2023-06-01'),
('Jane Smith', 1234567891, 'P002', 'Service not rendered in time', 3, '2023-06-02', 'Registered', '2023-06-02'),
('Alice Johnson', 1234567892, 'P003', 'Price charged is too high', 2, '2023-06-03', 'Registered', '2023-06-03');

-- Create necessary indexes
CREATE INDEX idx_product_code ON Product(Product_code);
CREATE INDEX idx_product_code_feature ON Product_Feature(Product_Code);
CREATE INDEX idx_city ON Outlet(City);
CREATE INDEX idx_complaint_date ON Complaint(Complaint_date);

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Pricing</title>
    <style>
        /* CSS styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }
        h1 {
            text-align: center;
            margin-top: 20px;
        }
        table {
            max-width: 500px;
            margin: 20px auto;
            background-color: #fff;
            border-collapse: collapse;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        button, .back-button, .clear-button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
            text-decoration: none; /* Remove underline */
            display: inline-block;
        }
        button:hover, .back-button:hover, .clear-button:hover {
            background-color: #45a049;
        }
        .clear-button {
            background-color: #f44336; /* Red background */
        }
        .back-button {
            background-color: #4CAF50; /* Green background */
        }
    </style>
</head>
<body>
    <h1>Product Pricing</h1>
    <form id="pricingForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <table>
            <tr>
                <th colspan="2">Enter Product Details</th>
            </tr>
            <tr>
                <td>Product:</td>
                <td>
                    <select name="product">
                        <option value="">Select Product</option>
                        <?php
                        include 'db.php';
                        // Fetch products from the database
                        $sql_products = "SELECT Product_Name FROM Product";
                        $result_products = $conn->query($sql_products);

                        if ($result_products->num_rows > 0) {
                            while ($row = $result_products->fetch_assoc()) {
                                echo '<option value="' . $row["Product_Name"] . '">' . $row["Product_Name"] . '</option>';
                            }
                        } else {
                            echo '<option value="">No products available</option>';
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Battery Required?</td>
                <td><input type="checkbox" name="batteryRequired"></td>
            </tr>
            <tr>
                <td>Service Location:</td>
                <td>
                    <input type="radio" name="serviceLocation" value="client" checked> At Client Place
                    <br>
                    <input type="radio" name="serviceLocation" value="center"> At Service Center
                </td>
            </tr>
            <tr>
                <td>Additional Warranty (Years):</td>
                <td><input type="number" name="additionalWarranty" min="0" max="2"></td>
            </tr>
            <tr>
                <td colspan="2" style="text-align: center;">
                    <button type="submit">Submit</button>
                    <button type="button" onclick="clearForm()" class="clear-button">Clear</button>
                    <a href="index.html" class="back-button">Back</a>
                </td>
            </tr>
        </table>
    </form>
    <div id="pricingDetails">
        <!-- Pricing details will be displayed here -->
        <?php
        include 'db.php';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Retrieve form data
            $productCode = isset($_POST['product']) ? $_POST['product'] : '';
            $serviceLocation = isset($_POST['serviceLocation']) ? $_POST['serviceLocation'] : '';
            $additionalWarranty = isset($_POST['additionalWarranty']) ? $_POST['additionalWarranty'] : 0;
            $batteryRequired = isset($_POST['batteryRequired']) ? 1 : 0;

            if (!empty($productCode)) {
                $stmt = $conn->prepare("SELECT * FROM Product WHERE Product_Name = ?");
                $stmt->bind_param("s", $productCode);
                $stmt->execute();
                $result = $stmt->get_result();
                $product = $result->fetch_assoc();

                if ($product) {
                    $basePrice = $product['Base_Price'];
                    $batteryPrice = $batteryRequired ? $product['Battery_Price'] : 0;
                    $serviceCost = $serviceLocation === 'client' ? ($basePrice + $batteryPrice) * ($product['Svc_at_Client_Place'] / 100) : 0;
                    $warrantyCost = $additionalWarranty * ($basePrice + $batteryPrice) * ($product['Addl_warranty_peryear'] / 100);
                    $finalPrice = $basePrice + $batteryPrice + $serviceCost + $warrantyCost;

                    // Display pricing details
                    echo "<table>";
                    echo "<tr><th colspan='2'>Pricing Details</th></tr>";
                    echo "<tr><td>Product:</td><td>$productCode</td></tr>";
                    echo "<tr><td>Base Price:</td><td>$basePrice</td></tr>";
                    echo "<tr><td>Battery Required?</td><td>".($batteryRequired ? 'Yes' : 'No')."</td></tr>";
                    echo "<tr><td>Service Location:</td><td>$serviceLocation</td></tr>";
                    echo "<tr><td>Additional Warranty (Years):</td><td>$additionalWarranty</td></tr>";
                    echo "<tr><td>Final Price:</td><td>$finalPrice</td></tr>";
                    echo "</table>";
                } else {
                    echo "Product not found!";
                }
            } else {
                echo "Product code is required!";
            }

            $conn->close();
        }
        ?>
    </div>

    <script>
        function clearForm() {
            document.getElementById('pricingForm').reset();
            document.getElementById('pricingDetails').innerHTML = '';
        }
    </script>
</body>
</html>


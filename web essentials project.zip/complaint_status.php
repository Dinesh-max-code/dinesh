<?php
include 'db.php';

// Initialize variables
$complaintNumber = '';
$errorMessage = '';
$complaint = null;
$productName = '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate input
    $complaintNumber = trim($_POST['complaintNumber']);
    if (!is_numeric($complaintNumber)) {
        $errorMessage = 'Please enter a valid complaint number.';
    } else {
        // Query the database for complaint details
        $stmt = $conn->prepare("SELECT * FROM Complaint WHERE Complaint_Number = ?");
        $stmt->bind_param("i", $complaintNumber);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $complaint = $result->fetch_assoc();
            
            // Query the product name associated with the complaint
            $productStmt = $conn->prepare("SELECT Product_Name FROM Product WHERE Product_code = ?");
            $productStmt->bind_param("s", $complaint['Product_code']);
            $productStmt->execute();
            $productResult = $productStmt->get_result();
            $product = $productResult->fetch_assoc();
            
            // Assign product name to variable
            $productName = $product['Product_Name'];
        } else {
            $errorMessage = 'Complaint not found. Please check the complaint number.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Query Complaint Status</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        form {
            margin-bottom: 20px;
            text-align: center;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 10px;
        }

        button:hover {
            background-color: #45a049;
        }

        .back-link {
            display: inline-block;
            margin-top: 10px;
            color: #333;
            text-decoration: none;
            font-weight: bold;
            border: 1px solid #333;
            padding: 5px 10px;
            border-radius: 4px;
        }

        .back-link:hover {
            background-color: #333;
            color: #fff;
        }

        .complaint-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .complaint-table th, .complaint-table td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .complaint-table th {
            background-color: #f2f2f2;
        }

        .complaint-table td {
            background-color: #fff;
        }

        .complaint-table th:first-child, .complaint-table td:first-child {
            border-left: none;
        }

        .complaint-table th:last-child, .complaint-table td:last-child {
            border-right: none;
        }

        .error-message {
            color: red;
            font-weight: bold;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Query Complaint Status</h1>
        <form id="queryStatusForm" method="post">
            <label for="complaintNumber">Complaint Number:</label>
            <input type="text" id="complaintNumber" name="complaintNumber" required>
            <button type="submit">Submit</button>
            <button type="button" onclick="clearForm()">Clear</button>
            <a href="index.html" class="back-link">Back</a>
        </form>
        <div id="complaintDetails">
            <?php if (!empty($complaint) && !empty($productName)): ?>
                <table class="complaint-table">
                    <tr>
                        <th>Complaint Number</th>
                        <td><?php echo $complaint['Complaint_Number']; ?></td>
                    </tr>
                    <tr>
                        <th>Product Name</th>
                        <td><?php echo $productName; ?></td>
                    </tr>
                    <tr>
                        <th>Complaint Details</th>
                        <td><?php echo $complaint['Complaint_details']; ?></td>
                    </tr>
                    <tr>
                        <th>Complaint Type</th>
                        <td><?php echo $complaint['Complaint_type']; ?></td>
                    </tr>
                    <tr>
                        <th>Complaint Date</th>
                        <td><?php echo $complaint['Complaint_date']; ?></td>
                    </tr>
                    <tr>
                        <th>Complaint Status</th>
                        <td><?php echo $complaint['Complaint_status']; ?></td>
                    </tr>
                    <tr>
                        <th>Status Date</th>
                        <td><?php echo $complaint['Status_date']; ?></td>
                    </tr>
                </table>
            <?php elseif (!empty($errorMessage)): ?>
                <p class="error-message"><?php echo $errorMessage; ?></p>
            <?php endif; ?>
        </div>
    </div>
    <script>
        function clearForm() {
            document.getElementById('queryStatusForm').reset();
            document.getElementById('complaintDetails').innerHTML = '';
        }
    </script>
</body>
</html>
